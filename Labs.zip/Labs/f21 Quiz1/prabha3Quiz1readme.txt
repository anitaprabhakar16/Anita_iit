#Table of Contents
    *Introduction 
    *Requirements/Process
    *Issues 
    *Inspiration
    *Credits 
    *Link to Website


#Introduction 
    - In this assignment, I used my previous knowledge of HTML and CSS to combine the new HTML document to my personal website created in Lab 2

#Requirements/Process
    - Though this assignment was fairly simple I was a bit confused as to what was being asked in the beginning. After some clarification from Professor Plotka< I realised what I needed to do. Creating a second CSS file I copied the style from the original HTML document and tased it into the new one. Then I linked both CSS filed to keep the formatting Professor used and my own so it blended nicely. 

#Issues 
    - Folders within my init folder. Since on my MacBook HTML documents read other documents contained in the same folder I had to combine all my pages in one folder.   

#Inspiration
    - Previous outline 
    - My personal website 

#Credits 
    - ITWS1100-F21-Quiz1Q2-Instructions.html

#Link to Website
    - file:///Users/anitaprabhakar/Desktop/iit/Labs/index.html