{\rtf1\ansi\ansicpg1252\cocoartf2513
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww28600\viewh15200\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 #Table of Contents\
    *Introduction \
    *Requirements/Restrictions\
    *Issues \
    *Inspiration\
    *Credits \
    *Link to Website\
\
\
#Introduction \
    - In this assignment, I was taught the basics of HTML and CSS. From this information, I was asked to turn my previous projects into a website. When doing this I also had to prepare for future content. \
\
#Requirements/Restrictions\
    - Though this assignment was fairly simple it had some limitations. The amount of <br /> tags used was restricted and formatting became a challenge. The use of pictures and links also brought up a few problems.\
\
#Issues \
    - Formating  \
    - Organizing \
    - Fixing errors \
    - Downloading and using FileZilla \
    - Using terminal\
\
#Inspiration\
    - Previous outline \
    - Simplicity with color\
    - Something that could be easily navigated \
\
#Credits \
    - \'93Where Developers Learn, Share, &amp; Build Careers.\'94 Stack Overflow, stackoverflow.com/. \
    - \'93Html.\'94 W3Schools Online Web Tutorials, www.w3schools.com/. \
    - https://validator.w3.org/nu/#file\
    - https://filezilla-project.org/download.php?type=client\
\
#Link to Website\
    - file:///Users/anitaprabhakar/Desktop/ITWS/Labs/Lab3/index.html}