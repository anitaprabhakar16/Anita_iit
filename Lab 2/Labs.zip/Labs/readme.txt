#Table of Contents
    *Introduction 
    *Requirements/Restrictions
    #Issues 
    #Inspiration
    *Credits 


#Introduction 
    - In this assignment, I was taught the basics of HTML and CSS. From this information, I was asked to turn my resume into an online website. 

#Requirements/Restrictions
    - Though this assignment was fairly simple it had some limitations. The amount of <br /> tags used was restricted and tables were not allowed. This brought up the challenge of formatting.  

#Issues 
    - Formating on the website 
    - Organizing my code 
    - Fixing bugs and errors 
    - Using the correct syntax code 

#Inspiration
    - My original resume 
    - The template given 
    - Previous websites I created 

#Credits 
    - “Where Developers Learn, Share, &amp; Build Careers.” Stack Overflow, stackoverflow.com/. 
    - “Html.” W3Schools Online Web Tutorials, www.w3schools.com/. 
