#Table of Contents 
	*Introduction 
	*Requirements/Restrictions
	*Issues
	*Inspiration
	*Credits 
	*Link to Website 

#Introduction: 
	- In this assignment I was given an HTML, CSS, and Javascript 
	  file. From there I was told to download XAMPP and given the 
	  rest of the assignment to complete.

#Requirements/Restrictions:
	- The requirements for this lab were fairly simple and the tag
	  I used/created for my website and lab was, 
	  <script>window.location.assign("http://www.rpi.edu");</script>

#Issues: 
	- The issues I came across were during the downloading of XAMPP
	  and finding the correct syntax and type of window.location tag.

#Inspiration
	- My inspiration came from the assignment material. Also, understanding
	  the reason the style tage work in the comments bar. This is because
	  of the way the HTML is set up that anything that is now put inside
	  of the comments field gets now put into the tags. From doing this
	  the style tags are read as actual style. 
#Credits
	- “Where Developers Learn, Share, &amp; Build Careers.” Stack Overflow, stackoverflow.com/. 
    	- “Html.” W3Schools Online Web Tutorials, www.w3schools.com/. 
    	- https://validator.w3.org 

#Links
    	- https://anitaprabhakar16.github.io/Anita_iit/


